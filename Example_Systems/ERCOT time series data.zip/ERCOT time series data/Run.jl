using GenX

run_genx_case!(dirname(@__FILE__))
